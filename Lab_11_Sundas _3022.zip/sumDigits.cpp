//#include <iostream>
//
//int sumDigits(int n)
//{
//    if (n > 0)
//        return (n % 10) + sumDigits(n / 10);
//    else
//        return n;
//}
//int main()
//{
//    int num, sum;
//    std::cout << "Enter a number: ";
//    std::cin >> num;
//    sum = sumDigits(num);
//    std::cout << "Sum: " << sum;
//    return 0;
//}
