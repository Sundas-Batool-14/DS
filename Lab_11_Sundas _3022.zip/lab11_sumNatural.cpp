//#include <iostream>
//
//int sumNatural(int n)
//{
//    if (n > 0)
//        return n + sumNatural(n - 1);
//    else
//        return n;
//}
//int main()
//{
//    int num, sum;
//    std::cout << "Enter a number: ";
//    std::cin >> num;
//    sum = sumNatural(num);
//    std::cout << "Sum: " << sum;
//    return 0;
//}
