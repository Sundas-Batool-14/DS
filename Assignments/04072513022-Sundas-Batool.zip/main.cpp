#include <iostream>
#include <cstdlib>
#include <algorithm>
#include <vector>
#include <forward_list>
#include <list>
#include <chrono>
#include "my_sort.h"
int main()
{
	//PART # 01
							//Vector Container

	std::vector<int> A, B, C, E, F, G;
	std::chrono::steady_clock::time_point start, finish;
	std::chrono::duration<double> elapsed_seconds;

	std::cout << "        Vector Container       " << std::endl;
	//Entering values 
	//vector A (Ascending order)
	start = std::chrono::steady_clock::now() ;
	for (int i = 1; i <= 100000; ++i) {
		A.push_back(i);
	}
	finish = std::chrono::steady_clock::now() ;
	elapsed_seconds = finish - start ;
	std::cout << "Entering vector A: " << elapsed_seconds.count() << std::endl;


	//vector B(Descending order)
	start = std::chrono::steady_clock::now() ;
	for (int i = 100000; i >= 1; --i){
		B.push_back(i);
	}
	finish = std::chrono::steady_clock::now();
	elapsed_seconds = finish - start;
	std::cout << "Entering vector B: " << elapsed_seconds.count() << std::endl;

	//Vector C(Random Values)
	start = std::chrono::steady_clock::now() ;
	for (int i = 1; i <= 100000; ++i){
		C.push_back( 1 + std::rand()%100000);
	}
	finish = std::chrono::steady_clock::now();
	elapsed_seconds = finish - start;
	std::cout << "Entering vector C: " << elapsed_seconds.count() << std::endl << std::endl;

	//saving the original vectors for part 2 
	std::vector <int> sA = A, sB = B, sC = C;

	//Sorting by using std::Sort

	//vector A
	start = std::chrono::steady_clock::now();
	std::sort(A.begin(), A.end());
	finish = std::chrono::steady_clock::now();
	elapsed_seconds = finish - start;
	std::cout << "Sorting vector A: " << elapsed_seconds.count() << std::endl;

	//vector B
	start = std::chrono::steady_clock::now();
	std::sort(B.begin(), B.end());
	finish = std::chrono::steady_clock::now();
	elapsed_seconds = finish - start;
	std::cout << "Sorting vector B: " << elapsed_seconds.count() << std::endl;

	//Vector C
	start = std::chrono::steady_clock::now();
	std::sort(C.begin(), C.end());
	finish = std::chrono::steady_clock::now();
	elapsed_seconds = finish - start;
	std::cout << "Sorting vector C: " << elapsed_seconds.count() << std::endl << std::endl;

	//Entering values 

	//Vector E(Ascending Order)
	start = std::chrono::steady_clock::now();
	for (int i = 1; i <= 100000; ++i){
		E.push_back(i);
	}
	finish = std::chrono::steady_clock::now();
	elapsed_seconds = finish - start;
	std::cout << "Entering vector E: " << elapsed_seconds.count() << std::endl;

	//Vector F(Descending order)
	start = std::chrono::steady_clock::now();
	for (int i = 100000; i >= 1; --i){
		F.push_back(i);
	}
	finish = std::chrono::steady_clock::now();
	elapsed_seconds = finish - start;
	std::cout << "Entering vector F: " << elapsed_seconds.count() << std::endl;

	//VEctor G(Random Values)
	start = std::chrono::steady_clock::now();
	for (int i = 1; i <= 100000; ++i){
		G.push_back(1 + std::rand() % 100000);
	}
	finish = std::chrono::steady_clock::now();
	elapsed_seconds = finish - start;
	std::cout << "Entering vector G: " << elapsed_seconds.count() << std::endl << std::endl;

	//Erasing odd values from E,F and G
	//E
	start = std::chrono::steady_clock::now();
	std::erase_if(E, [](int n) -> bool { return n % 2 != 0; });
	finish = std::chrono::steady_clock::now();
	elapsed_seconds = finish - start;
	std::cout << std::endl << "Removing odd values from E: " << elapsed_seconds.count() << std::endl;

	//F
	start = std::chrono::steady_clock::now();
	std::erase_if(F, [](int n) -> bool { return n % 2 != 0; });
	finish = std::chrono::steady_clock::now();
	elapsed_seconds = finish - start;
	std::cout << "Removing odd values from F: " << elapsed_seconds.count() << std::endl;

	//G
	start = std::chrono::steady_clock::now();
	std::erase_if(G, [](int n) -> bool { return n % 2 != 0; });
	finish = std::chrono::steady_clock::now();
	elapsed_seconds = finish - start;
	std::cout << "Removing odd values from G: " << elapsed_seconds.count() << std::endl;



    //Part # 02
		//sorting vector values using own heap_sort and insertion_sort
		//Sorting A,B,C using heap_Sort
	my_sort s;

	//A
	start = std::chrono::steady_clock::now();
	s.heapSort(sA);
	finish = std::chrono::steady_clock::now();
	elapsed_seconds = finish - start;
	std::cout << std::endl << "Sorting vector A by heap sort: " << elapsed_seconds.count() << std::endl;

	//B
	start = std::chrono::steady_clock::now();
	s.heapSort(sB);
	finish = std::chrono::steady_clock::now();
	elapsed_seconds = finish - start;
	std::cout << "Sorting vector B by heap sort: " << elapsed_seconds.count() << std::endl;

	//C
	start = std::chrono::steady_clock::now();
	s.heapSort(sC);
	finish = std::chrono::steady_clock::now();
	elapsed_seconds = finish - start;
	std::cout << "Sorting vector C by heap sort: " << elapsed_seconds.count() << std::endl;


	//Sorting E,F,G using insertion_sort
	//E
	start = std::chrono::steady_clock::now();
	s.insertionSort(E, E.size());
	finish = std::chrono::steady_clock::now();
	elapsed_seconds = finish - start;
	std::cout <<std::endl<< "Sorting vector E by insertion sort: " << elapsed_seconds.count() << std::endl;

	//F
	start = std::chrono::steady_clock::now();
	s.insertionSort(F, F.size());
	finish = std::chrono::steady_clock::now();
	elapsed_seconds = finish - start;
	std::cout << "Sorting vector F by insertion sort: " << elapsed_seconds.count() << std::endl;

	//G
	start = std::chrono::steady_clock::now();
	s.insertionSort(G, G.size());
	finish = std::chrono::steady_clock::now();
	elapsed_seconds = finish - start;
	std::cout << "Sorting vector G by insertion sort: " << elapsed_seconds.count() << std::endl;



	//Part # 01
										//Forward_List Container

	std::forward_list<int> fA, fB, fC, fD, fE, fF, fG;

	std::cout << std::endl << "        Forward_list Container       " << std::endl;

	//Entering values in forward_list 
	// A (Ascending)
	start = std::chrono::steady_clock::now();
	for (int i = 100000; i >= 1; --i) {
		fA.push_front(i);
	}
	finish = std::chrono::steady_clock::now();
	elapsed_seconds = finish - start;
	std::cout << "Entering forward_list A: " << elapsed_seconds.count() << std::endl;

	//B (Descending)
	start = std::chrono::steady_clock::now();
	for (int i = 1; i <= 100000; ++i) {
		fB.push_front(i);
	}
	finish = std::chrono::steady_clock::now();
	elapsed_seconds = finish - start;
	std::cout << "Entering forward_list B: " << elapsed_seconds.count() << std::endl;

	//C (Random)
	start = std::chrono::steady_clock::now();
	for (int i = 1; i <= 100000; ++i) {
		fC.push_front(i);
	}
	finish = std::chrono::steady_clock::now();
	elapsed_seconds = finish - start;
	std::cout << "Entering forward_list C: " << elapsed_seconds.count() << std::endl << std::endl;

	//Sorting A,B,C using STL sort 

	// A
	start = std::chrono::steady_clock::now();
	fA.sort();
	finish = std::chrono::steady_clock::now();
	elapsed_seconds = finish - start;
	std::cout << "Sorting forward_list A: " << elapsed_seconds.count() << std::endl;

	//B
	start = std::chrono::steady_clock::now();
	fB.sort();
	finish = std::chrono::steady_clock::now();
	elapsed_seconds = finish - start;
	std::cout << "Sorting forward_list B: " << elapsed_seconds.count() << std::endl;

	//C
	start = std::chrono::steady_clock::now();
	fC.sort();
	finish = std::chrono::steady_clock::now();
	elapsed_seconds = finish - start;
	std::cout << "Sorting forward_list C: " << elapsed_seconds.count() << std::endl << std::endl;

	//Entering values in E,F,G

	//E(Ascending)
	start = std::chrono::steady_clock::now();
	for (int i = 1; i <= 100000; ++i) {
		fE.push_front(i);
	}
	finish = std::chrono::steady_clock::now();
	elapsed_seconds = finish - start;
	std::cout << "Entering forward_list E: " << elapsed_seconds.count() << std::endl;

	//F(Descending)
	start = std::chrono::steady_clock::now();
	for (int i = 100000; i >= 1; --i) {
		fF.push_front(i);
	}
	finish = std::chrono::steady_clock::now();
	elapsed_seconds = finish - start;
	std::cout << "Entering forward_list F: " << elapsed_seconds.count() << std::endl;

	//G(Random)
	start = std::chrono::steady_clock::now();
	for (int i = 1; i <= 100000; ++i) {
		fG.push_front(1 + rand() % 100000);
	}
	finish = std::chrono::steady_clock::now();
	elapsed_seconds = finish - start;
	std::cout << "Entering forward_list G: " << elapsed_seconds.count() << std::endl;

	//Removing odd values from E,F,G
	//E
	start = std::chrono::steady_clock::now();
	std::erase_if(fE, [](int n) -> bool { return n % 2 != 0; });
	finish = std::chrono::steady_clock::now();
	elapsed_seconds = finish - start;
	std::cout << std::endl << "Removing odd values from E: " << elapsed_seconds.count() << std::endl;

	//F
	start = std::chrono::steady_clock::now();
	std::erase_if(fF, [](int n) -> bool { return n % 2 != 0; });
	finish = std::chrono::steady_clock::now();
	elapsed_seconds = finish - start;
	std::cout << "Removing odd values from F: " << elapsed_seconds.count() << std::endl;

	//G
	start = std::chrono::steady_clock::now();
	std::erase_if(fG, [](int n) -> bool { return n % 2 != 0; });
	finish = std::chrono::steady_clock::now();
	elapsed_seconds = finish - start;
	std::cout << "Removing odd values from G:" << elapsed_seconds.count() << std::endl;



								//List Container

	std::list<int> lA, lB, lC, lE, lF, lG;
	std::cout << std::endl << "       List Container       " << std::endl;

	//Entering values in A,B,C

	//A (Ascending)
	start = std::chrono::steady_clock::now();
	for (int i = 1; i <= 100000; ++i) {
		lA.push_back(i);
	}
	finish = std::chrono::steady_clock::now();
	elapsed_seconds = finish - start;
	std::cout << "Entering list A: " << elapsed_seconds.count() << std::endl;

	//B (Descending)
	start = std::chrono::steady_clock::now();
	for (int i = 100000; i >= 1; --i) {
		lB.push_back(i);
	}
	finish = std::chrono::steady_clock::now();
	elapsed_seconds = finish - start;
	std::cout << "Entering list B: " << elapsed_seconds.count() << std::endl;

	//C(Random)
	start = std::chrono::steady_clock::now();
	for (int i = 1; i <= 100000; ++i) {
		lC.push_back(1 + rand() % 100000);
	}
	finish = std::chrono::steady_clock::now();
	elapsed_seconds = finish - start;
	std::cout << "Entering list C: " << elapsed_seconds.count() << std::endl << std::endl;

	//Sorting by STL sort

	//A
	start = std::chrono::steady_clock::now();
	lA.sort();
	finish = std::chrono::steady_clock::now();
	elapsed_seconds = finish - start;
	std::cout << "Sorting list A: " << elapsed_seconds.count() << std::endl;

	//B
	start = std::chrono::steady_clock::now();
	lB.sort();
	finish = std::chrono::steady_clock::now();
	elapsed_seconds = finish - start;
	std::cout << "Sorting list B: " << elapsed_seconds.count() << std::endl;

	//C
	start = std::chrono::steady_clock::now();
	lC.sort();
	finish = std::chrono::steady_clock::now();
	elapsed_seconds = finish - start;
	std::cout << "Sorting list C: " << elapsed_seconds.count() << std::endl << std::endl;


	//Entering values in E,F,G

	//E(Ascending)
	start = std::chrono::steady_clock::now();
	for (int i = 1; i <= 100000; ++i) {
		lE.push_front(i);
	}
	finish = std::chrono::steady_clock::now();
	elapsed_seconds = finish - start;
	std::cout << "Entering list E: " << elapsed_seconds.count() << std::endl;

	//F(Descending)
	start = std::chrono::steady_clock::now();
	for (int i = 100000; i >= 1; --i) {
		lF.push_front(i);
	}
	finish = std::chrono::steady_clock::now();
	elapsed_seconds = finish - start;
	std::cout << "Entering list F: " << elapsed_seconds.count() << std::endl;

	//G(random)
	start = std::chrono::steady_clock::now();
	for (int i = 1; i <= 100000; ++i) {
		lG.push_front(1 + rand() % 100000);
	}
	finish = std::chrono::steady_clock::now();
	elapsed_seconds = finish - start;
	std::cout << "Entering list G: " << elapsed_seconds.count() << std::endl;

	//Removing odd values from E,F,G
	//E
	start = std::chrono::steady_clock::now();
	std::erase_if(lE, [](int n) -> bool { return n % 2 != 0; });
	finish = std::chrono::steady_clock::now();
	elapsed_seconds = finish - start;
	std::cout <<std::endl<< "Removing odd values from E: " << elapsed_seconds.count() << std::endl;

	//F
	start = std::chrono::steady_clock::now();
	std::erase_if(lF, [](int n) -> bool { return n % 2 != 0; });
	finish = std::chrono::steady_clock::now();
	elapsed_seconds = finish - start;
	std::cout << "Removing odd values from F: " << elapsed_seconds.count() << std::endl;

	//G
	start = std::chrono::steady_clock::now();
	std::erase_if(lG, [](int n) -> bool { return n % 2 != 0; });
	finish = std::chrono::steady_clock::now();
	elapsed_seconds = finish - start;
	std::cout << "Removing odd values from G: " << elapsed_seconds.count() << std::endl;

	return 0;
}
