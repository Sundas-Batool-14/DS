#pragma once
#include <iostream>
#include <vector>

class my_sort {
public:
	void insertionSort(std::vector<int>& v, int n)
	{
		int num, i, j;
		for ( i = 1; i < n; ++i)
		{
			num = v[i];
			for ( j = i - 1; j >= 0; --j)
			{
				if (num < v[j])
					v[j + 1] = v[j];
				else
					break;
			}
			v[j + 1] = num;
		}
	}
	void heap(std::vector<int>& v, int first, int last)
	{
		int left, right, max;
		left = first * 2 + 1;
		right = first * 2 + 2;
		max = left;
		while (left <= last)
		{
			if (right <= last)
			{
				if (v[right] > v[left])
					max = right;
			}
			if (v[first] < v[max])
			{
				std::swap(v[first], v[max]);
				first = max;
				left = first * 2 + 1;
				right = first * 2 + 2;
				max = left;
			}
			else
				break;
		}
	}
	void heapSort(std::vector<int>& v)
	{
		if (v.size() < 2)
			return;
		for (int i = (v.size() / 2) - 1; i >= 0; --i)
		{
			heap(v, i, v.size() - 1);
		}
		int i = v.size() - 1;
		while (i != 0)
		{
			std::swap(v[i], v[0]);
			heap(v, 0, i - 1);
			--i;
		}
	}


};