#include <iostream>
#include <string>
#include <stack>

int main()
{
    std::stack<char> stk;
    std::string exp;

    std::cout << "Enter string: ";
    std::cin>> exp;

    for (int i = 0; i < exp.length(); i++)
    {
        char c = exp[i];

        if (c == '(' || c == '{' || c == '[')
        {
            stk.push(c);
        }
        else if (c == ')' || c == '}' || c == ']')
        {
            if (stk.empty())
            {
                std::cout << "Error at " << i << ": unexpected closer '" << c << "'";
                return 0;
            }

            char top = stk.top();

            if ((c == ')' && top != '(') ||
                (c == '}' && top != '{') ||
                (c == ']' && top != '['))
            {
                char expected;

                if (top == '(')
                    expected = ')';
                else if (top == '{')
                    expected = '}';
                else
                    expected = ']';

                std::cout << "Error at " << i << ": expected '"
                    << expected << "' but found '" << c << "'";
                return 0;
            }

            stk.pop();
        }
    }

    if (!stk.empty())
    {
        std::cout << "Error: unclosed opener '" << stk.top() << "'";
    }
    else
    {
        std::cout << "Balanced";
    }

    return 0;
}
