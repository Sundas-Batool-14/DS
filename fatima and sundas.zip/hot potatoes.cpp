
#include <iostream>
#include<queue>
int main()
{
    int n = 7;
    int k = 3;
    int temp;

    std::queue <int> persons;
    for (int i = 1; i <= n; ++i)
    {
        persons.push(i);
    }
    std::cout << "Eliminated: ";
    while (persons.size() > 1)
    {
        for (int i = 1; i <= k; ++i)
        {
            temp = persons.front();
            persons.push(temp);
            persons.pop();
        }
        
        std::cout << persons.front();
        persons.pop();
    }

    std::cout << std::endl << "Winner :" << persons.front() << std::endl;
}

