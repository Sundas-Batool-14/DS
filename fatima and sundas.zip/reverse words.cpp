
#include <iostream>
#include <stack>
#include <string>
void reverse(std::string& st)
{
    std::stack<char>s1, s2;
    for (int i = 0 ; i <= st.length(); ++i)
    {
        s1.push(st[i]);
        
    }
    while (!s1.empty()) {
        std::cout << s1.top();
       // s2.push(s1.top());
        s1.pop();
    }
    std::cout << std::endl;
    std::string c = "";

    for (int i=0; i <= st.length();++i)
    {
        if (st[i] != ' ')
        {
            c += st[i];
        }
        else {
            for (int j = c.length(); j >= 0; --j)
            {
                s2.push(c[j]);

            }
            s2.push(' ');
            c = "";
        }
        
        
    }
    for (int j = c.length(); j >= 0; --j)
    {
        s2.push(c[j]);

    }

    while (!s2.empty()) {
        std::cout << s2.top();
        s2.pop();
    }
}
int main()
{
    std::string s ="data structures are fun";
    reverse(s);

}
